"use strict";
exports.id = 511;
exports.ids = [511];
exports.modules = {

/***/ 6041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TagSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/ui/Headline.tsx
var Headline = __webpack_require__(8547);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(949);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/navigation.ts
var navigation = __webpack_require__(9577);
;// CONCATENATED MODULE: ./components/tags/TagItem.tsx





const getFont = (size)=>{
    const map = {
        1: "font-semibold",
        2: "font-normal",
        3: "font-medium",
        4: "font-semibold",
        5: "font-bold"
    };
    return map[size] ?? "font-medium";
};
const getTextSize = (size)=>{
    const map = {
        1: "text-xl",
        2: "text-2xl",
        3: "text-3xl",
        4: "text-lg",
        5: "text-4xl"
    };
    return map[size] ?? "text-xl";
};
const TagItem = ({ tag , design ="tag" , useSize =false , size =0 ,  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: (0,navigation/* buildTagUrl */.V1)(tag, "tag"),
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            children: design === "tag" ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (0,helpers/* classNames */.AK)("text-sm md:text-base leading-5 mr-2", useSize ? getFont(size) : "font-medium", "text-color bg-secondary/10 rounded-full py-1 px-3 hover:bg-secondary/30 hover:brightness-125 mb-2 hover:scale-[1.05] duration-300 ease-in shadow-md"),
                children: tag
            }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (0,helpers/* classNames */.AK)(getTextSize(size), "flex mr-2 p-1 font-semibold text-alternative hover:text-main"),
                children: tag
            })
        })
    });
};
/* harmony default export */ const tags_TagItem = (TagItem);

;// CONCATENATED MODULE: ./components/tags/TagSection.tsx




const TagsSection = ({ headline , tags , variant ="h2" , design ="tag" ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Headline/* default */.Z, {
                variant: variant,
                text: headline
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (0,helpers/* classNames */.AK)("flex flex-row content-around flex-wrap my-5", design === "tag" ? "items-center" : "items-baseline"),
                children: tags.map((tag, i)=>/*#__PURE__*/ jsx_runtime_.jsx(tags_TagItem, {
                        tag: tag,
                        design: design
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const TagSection = (TagsSection);


/***/ }),

/***/ 4320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ videos_VideosSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/ui/Headline.tsx
var Headline = __webpack_require__(8547);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
// EXTERNAL MODULE: external "millify"
var external_millify_ = __webpack_require__(9542);
var external_millify_default = /*#__PURE__*/__webpack_require__.n(external_millify_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./utils/navigation.ts
var navigation = __webpack_require__(9577);
;// CONCATENATED MODULE: ./components/videos/VideoTagItem.tsx




const VideoTagItem = ({ tag , role ="tag"  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: (0,navigation/* buildTagUrl */.V1)(tag, role),
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "font-medium text-sm text-color bg-secondary/10 rounded-full px-3 mb-1 hover:brightness-125 hover:bg-secondary/30 mr-2 hover:scale-[1.05] duration-300 ease-in shadow-md",
                children: tag
            })
        })
    });
};
/* harmony default export */ const videos_VideoTagItem = (VideoTagItem);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./utils/time.ts
const formatTimeFull = (duration)=>{
    if (duration <= 59 && duration <= 9) return `00:0${duration}`;
    if (duration <= 59) return `00:${duration}`;
    const seconds = duration % 60;
    return `${Math.floor(duration / 60)}:${seconds <= 9 ? "0" + seconds : seconds}`;
};
const formatTimeLite = (duration, showSeconds = false)=>{
    if (duration <= 59) return `${duration} sec`;
    return `${Math.floor(duration / 60)} min` + (showSeconds ? ` ${duration % 60} sec` : "");
};

;// CONCATENATED MODULE: ./components/videos/VideoItem.tsx









const VideoItem = ({ video , showHd =false , showViews =false , showDuration =false , showTags =false ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "text-main justify-items-center overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: (0,navigation/* buildVideoUrl */.J9)(String(video.id)),
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "relative group",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-xl",
                                    alt: video.title,
                                    src: video.thumbnail,
                                    layout: "responsive",
                                    width: 400,
                                    height: 250
                                }),
                                showHd && video.isHD && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "bg-secondary py-1 px-2 bg-opacity-90 text-inverted text-xs font-semibold rounded-md absolute top-2 right-2 group-hover:opacity-0 duration-500 ease-in-out",
                                    children: "HD"
                                }),
                                showViews && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "bg-black py-1 px-2 bg-opacity-80 text-inverted text-xs font-light rounded-md absolute bottom-2 left-2 inline-flex group-hover:opacity-0 duration-500 ease-in-out items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(outline_.EyeIcon, {
                                            className: "w-4 h-4 mr-1"
                                        }),
                                        " ",
                                        external_millify_default()(video.views)
                                    ]
                                }),
                                showDuration && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "bg-black bg-opacity-80 py-1 px-2 text-inverted text-xs font-light rounded-md absolute bottom-2 right-2 inline-flex group-hover:opacity-0 duration-500 ease-in-out items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(outline_.ClockIcon, {
                                            className: "w-4 h-4 mr-1"
                                        }),
                                        formatTimeLite(video.duration)
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mx-2 mt-2 line-clamp-2 mb-2 font-semibold",
                            children: video.title
                        })
                    ]
                })
            }),
            showTags && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-2 mx-2 mt-1 flex flex-row content-around flex-wrap",
                children: [
                    video.categories.length > 0 && video.categories.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx(videos_VideoTagItem, {
                            role: "category",
                            tag: tag
                        }, tag)),
                    video.models.length > 0 && video.models.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx(videos_VideoTagItem, {
                            role: "model",
                            tag: tag
                        }, tag))
                ]
            })
        ]
    });
};
/* harmony default export */ const videos_VideoItem = (VideoItem);

;// CONCATENATED MODULE: ./components/videos/VideosSection.tsx




const VideosSection = ({ headline , videos , variant ="h1"  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Headline/* default */.Z, {
                variant: variant,
                text: headline
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:gird-cols-4 gap-5 my-6",
                children: videos.map((video)=>/*#__PURE__*/ jsx_runtime_.jsx(videos_VideoItem, {
                        video: video,
                        showHd: true,
                        showViews: true,
                        showDuration: true
                    }, video.id))
            })
        ]
    });
};
/* harmony default export */ const videos_VideosSection = (VideosSection);


/***/ }),

/***/ 7235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jf": () => (/* binding */ videoFullSelector),
/* harmony export */   "QA": () => (/* binding */ videoPreviewSelector),
/* harmony export */   "uT": () => (/* binding */ categorySelector)
/* harmony export */ });
const videoSelector = {
    _id: 0,
    id: 1,
    src: 1,
    title: 1,
    tags: 1,
    models: 1,
    categories: 1,
    views: 1,
    duration: 1,
    slug: 1,
    isHD: 1,
    likes: 1,
    dislikes: 1
};
const videoPreviewSelector = {
    ...videoSelector,
    thumbnail: 1
};
const videoFullSelector = {
    ...videoSelector,
    poster: 1,
    createdAt: 1
};
const categorySelector = {
    _id: 0,
    id: 1,
    name: 1,
    role: 1,
    image: 1,
    videoCount: 1
};


/***/ }),

/***/ 1249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "lY": () => (/* binding */ getRandomVideos),
  "mJ": () => (/* binding */ getVideoById),
  "Uw": () => (/* binding */ searchRelatedVideos),
  "oo": () => (/* binding */ searchVideos)
});

// UNUSED EXPORTS: getVideoBySlug, getVideos, videoExists

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./database/models/counter.model.ts

const counterSchema = new (external_mongoose_default()).Schema({
    _id: {
        type: String,
        required: true
    },
    seq: {
        type: Number,
        default: 0
    }
});
const Counter = (external_mongoose_default()).models.Counter || external_mongoose_default().model("Counter", counterSchema);
/* harmony default export */ const counter_model = (Counter);

;// CONCATENATED MODULE: ./database/models/videos.model.ts


const videosSchema = new (external_mongoose_default()).Schema({
    id: {
        type: Number,
        required: [
            true,
            "video id is required"
        ],
        unique: true,
        min: 1
    },
    slug: {
        required: [
            true,
            "slug is required"
        ],
        type: String
    },
    src: {
        required: [
            true,
            "src is required"
        ],
        type: String
    },
    title: {
        required: [
            true,
            "title is required"
        ],
        type: String,
        unique: true,
        trim: true
    },
    thumbnail: {
        required: [
            true,
            "thumbnail is required"
        ],
        type: String
    },
    poster: {
        required: [
            true,
            "poster is required"
        ],
        type: String
    },
    alternativeTitle: {
        type: String,
        default: "",
        trim: true
    },
    isHD: {
        type: Boolean,
        default: true
    },
    duration: {
        type: Number,
        required: [
            true,
            "duration is required"
        ]
    },
    plattform: {
        type: String,
        required: [
            true,
            "plattform is required"
        ]
    },
    originalId: {
        type: String,
        required: [
            true,
            "originalId is required"
        ]
    },
    originalImage: {
        type: String,
        required: [
            true,
            "originalImage is required"
        ]
    },
    views: {
        type: Number,
        default: 1
    },
    likes: {
        type: Number,
        default: 0
    },
    dislikes: {
        type: Number,
        default: 0
    },
    tags: {
        default: [],
        type: [
            String
        ]
    },
    categories: {
        default: [],
        type: [
            String
        ]
    },
    models: {
        default: [],
        type: [
            String
        ]
    },
    isUp: {
        default: true,
        type: Boolean
    },
    lastUpCheck: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});
videosSchema.pre("save", function(next) {
    var doc = this;
    counter_model.findByIdAndUpdate({
        _id: "videos"
    }, {
        $inc: {
            seq: 1
        }
    }, {
        new: true,
        upsert: true
    }, function(error, counter) {
        if (error) return next(error);
        doc.id = counter.seq;
        next();
    });
});
videosSchema.index({
    title: "text",
    alternativeTitle: "text",
    tags: "text",
    categories: "text",
    models: "text"
});
const videos_model_Videos = (external_mongoose_default()).models.Videos || external_mongoose_default().model("Videos", videosSchema);
/* harmony default export */ const videos_model = (videos_model_Videos);

;// CONCATENATED MODULE: ./database/services/videos.service.ts

const getRandomVideos = async (amount, select = {})=>{
    try {
        const videos = videos_model.aggregate([
            {
                $sample: {
                    size: amount
                }
            },
            {
                $project: select
            }, 
        ]);
        if (!videos) throw new Error(`Could not find ${amount} Videos`);
        return videos;
    } catch (error) {
        throw error;
    }
};
const videoExists = async (id)=>{
    const video = await Videos.findOne({
        id
    });
    if (!video) return false;
    return true;
};
const getVideoById = async (id, increaseViews = false, select = {})=>{
    try {
        let video;
        increaseViews ? video = await videos_model.findOneAndUpdate({
            id: id
        }, {
            $inc: {
                views: 1
            }
        }).select(select) : video = await videos_model.findOne({
            id: id
        }).select(select);
        if (!video) throw new Error(`Video with id ${id} not found.`);
        return video;
    } catch (error) {
        throw error;
    }
};
const getVideoBySlug = async (slug, increaseViews = false, select = {})=>{
    try {
        console.log(slug);
        let video;
        increaseViews ? video = await Videos.findOneAndUpdate({
            slug: slug
        }, {
            $inc: {
                views: 1
            }
        }).select(select) : video = await Videos.findOne({
            slug: slug
        }).select(select);
        if (!video) return null;
        console.log(video);
        return video;
    } catch (error) {
        throw error;
    }
};
const getVideos = async (page, limit, select = {}, sort = {
    createdAt: -1
}, search = "")=>{
    try {
        const skip = page * limit - limit;
        const videos = Videos.find(search.length > 0 ? {
            title: {
                $regex: `\\b${search}\\b`,
                $options: "i"
            }
        } : {}).skip(skip).limit(limit).sort(sort).select(select);
        return videos;
    } catch (error) {
        throw error;
    }
};
const searchRelatedVideos = async (id, keyword, limit, select = {})=>{
    try {
        const videos = await videos_model.find({
            id: {
                $ne: id
            },
            $text: {
                $search: keyword,
                $caseSensitive: true,
                $diacriticSensitive: true
            },
            score: {
                $meta: "textScore"
            }
        }).sort({
            score: {
                $meta: "textScore"
            }
        }).limit(limit).select(select);
        return videos;
    } catch (err) {
        return [];
    }
};
const searchVideos = async (keyword, limit, select = {})=>{
    try {
        const videos = await videos_model.find({
            $text: {
                $search: keyword,
                $caseSensitive: false,
                $diacriticSensitive: false
            },
            score: {
                $meta: "textScore"
            }
        }).sort({
            score: {
                $meta: "textScore"
            }
        }).limit(limit).select(select);
        return videos;
    } catch (err) {
        return [];
    }
};


/***/ })

};
;