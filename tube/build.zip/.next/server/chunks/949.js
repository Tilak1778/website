"use strict";
exports.id = 949;
exports.ids = [949];
exports.modules = {

/***/ 8486:
/***/ ((module) => {


const sharedConfig = {
    videosLimit: 40,
    tagsLimit: 15,
    maxPage: 5
};
module.exports = {
    /** Routes **/ routes: {
        index: "index",
        video: "video",
        tag: "tag",
        category: "category",
        model: "model",
        toplist: "models",
        top: "top",
        new: "new"
    },
    /** Index Page **/ index: {
        identifier: "index",
        videosLimit: 40,
        tagsLimit: 15,
        categoriesSectionRole: "category",
        categoriesSectionLimit: 20
    },
    /** Video Page **/ video: {
        identifier: "video",
        videosLimit: 40,
        tagsLimit: 15
    },
    /** Tag Page **/ tag: {
        identifier: "tag",
        ...sharedConfig
    },
    /** Category Page **/ category: {
        identifier: "category",
        ...sharedConfig
    },
    /** Model Page **/ model: {
        identifier: "model",
        ...sharedConfig
    },
    /** Toplist Page **/ toplist: {
        identifier: "toplist",
        listLimit: 100,
        role: "model"
    },
    /** New Page **/ new: {
        identifier: "new",
        ...sharedConfig
    },
    /** Top Page **/ top: {
        identifier: "top",
        ...sharedConfig
    }
};


/***/ }),

/***/ 949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AK": () => (/* binding */ classNames),
/* harmony export */   "Bv": () => (/* binding */ getRoute),
/* harmony export */   "Qs": () => (/* binding */ toJson),
/* harmony export */   "VI": () => (/* binding */ slugifyAndPage),
/* harmony export */   "fx": () => (/* binding */ getPage),
/* harmony export */   "h": () => (/* binding */ validateTagRole),
/* harmony export */   "im": () => (/* binding */ validateNavPages),
/* harmony export */   "tP": () => (/* binding */ getTagRoleByRoute),
/* harmony export */   "vf": () => (/* binding */ removePageFromPath)
/* harmony export */ });
/* unused harmony exports slugify, addPage, getVideoId */
/* harmony import */ var tube_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8486);
/* harmony import */ var tube_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tube_config__WEBPACK_IMPORTED_MODULE_0__);

function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
const slugify = (str)=>{
    return str.toString().toLowerCase().replace(/\s+/g, "-") // Replace spaces with -
    .replace(/[^\w\-]+/g, "-") // Remove all non-word chars
    .replace(/\-\-+/g, "-") // Replace multiple - with single -
    .replace(/^-+/, "") // Trim - from start of text
    .replace(/-+$/, "");
};
const slugifyAndPage = (str, page = 1)=>{
    return addPage(slugify(str), page);
};
const addPage = (str, page = 1)=>{
    return str.concat(`-${page}`);
};
const getPage = (str)=>{
    try {
        const pos = str.lastIndexOf("-");
        if (pos === -1) return null;
        const keyword = str.substring(0, pos);
        const page = str.substring(pos + 1);
        if (isNaN(parseFloat(page)) || isNaN(+page)) return null;
        return {
            keyword: keyword.replaceAll("-", " "),
            page: parseFloat(page)
        };
    } catch (err) {
        console.log(err);
        return null;
    }
};
const toJson = (value)=>{
    return JSON.parse(JSON.stringify(value));
};
const getRoute = (routeName)=>{
    return tube_config__WEBPACK_IMPORTED_MODULE_0__.routes[routeName];
};
const getVideoId = (id)=>{
    try {
        if (isNaN(parseFloat(id)) || isNaN(+id)) return null;
        return parseFloat(id);
    } catch (err) {
        return null;
    }
};
const validateTagRole = (str)=>{
    if (getRoute("tag") === str || getRoute("category") === str || getRoute("model") === str) {
        return true;
    }
    return false;
};
const validateNavPages = (str)=>{
    if (getRoute("top") === str || getRoute("new") === str) {
        return true;
    }
    return false;
};
const getTagRoleByRoute = (str)=>{
    const res = Object.keys(tube_config__WEBPACK_IMPORTED_MODULE_0__.routes).find((key)=>{
        return tube_config__WEBPACK_IMPORTED_MODULE_0__.routes[key] === str;
    });
    return res;
};
const removePageFromPath = (path)=>{
    const pos = path.lastIndexOf("-");
    if (pos === -1) return path;
    return path.substring(0, pos);
};


/***/ })

};
;