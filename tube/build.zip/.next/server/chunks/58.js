"use strict";
exports.id = 58;
exports.ids = [58];
exports.modules = {

/***/ 2058:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ feedback_Feedback)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(949);
;// CONCATENATED MODULE: ./components/ui/Alert.tsx



const Alert = ({ message , alertType ="default"  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: message && /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (0,helpers/* classNames */.AK)(alertType === "default" ? "text-sky-400 border-sky-700/70 bg-sky-500/20" : "", alertType === "danger" ? "text-red-400 border-red-700/70 bg-red-500/20" : "", alertType === "success" ? "text-emerald-400 border-emerald-700/70 bg-emerald-400/20" : "", "border-2 text-center rounded-md p-2 mb-4 text-sm mt-2"),
            children: message
        })
    });
};
/* harmony default export */ const ui_Alert = (Alert);

// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
;// CONCATENATED MODULE: ./components/ui/Dropdown.tsx




const DropDown = ({ items , selectedQuery , updateFilterQuery  })=>{
    const selectedItem = items.find((item)=>item.query === selectedQuery);
    const { 0: showDropdown , 1: setShowDropdown  } = (0,external_react_.useState)(false);
    const dropdownRef = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const handleOutsideClicks = (event)=>{
            if (showDropdown && dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setShowDropdown(false);
            }
        };
        document.addEventListener("mousedown", handleOutsideClicks);
        return ()=>{
            document.removeEventListener("mousedown", handleOutsideClicks);
        };
    }, [
        showDropdown
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        ref: dropdownRef,
        className: "relative flex flex-row justify-between items-center w-full md:w-auto rounded-md text-sm font-medium bg-primary text-alternative shadow-sm cursor-pointer min-w-[10rem]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                type: "button",
                className: "flex justify-between items-center px-4 py-2 md:py-3 w-full focus:outline-none text-main font-semibold",
                onClick: ()=>{
                    setShowDropdown(!showDropdown);
                },
                children: [
                    selectedItem?.label,
                    /*#__PURE__*/ jsx_runtime_.jsx(outline_.ChevronDownIcon, {
                        className: "flex w-5 h-5"
                    })
                ]
            }),
            showDropdown && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "z-50 absolute right-0 top-10 md:top-12 rounded-md w-full bg-primary text-alternative shadow-lg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "py-1",
                    children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: ()=>{
                                updateFilterQuery(item.query);
                                setShowDropdown(false);
                            },
                            className: (0,helpers/* classNames */.AK)(item.query === selectedQuery ? "text-main" : "", "block px-4 py-2 text-sm hover:bg-secondary/30 cursor-pointer"),
                            children: item.label
                        }, item.query))
                })
            })
        ]
    });
};
/* harmony default export */ const Dropdown = (DropDown);

;// CONCATENATED MODULE: ./hooks/useOutsideDetection.ts
/* eslint-disable react-hooks/exhaustive-deps */ 
const useOutsideDetection = (ref, cb)=>{
    (0,external_react_.useEffect)(()=>{
        function handleClickOutside(event) {
            if (ref.current && !ref.current.contains(event.target)) {
                cb();
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        ref
    ]);
};
/* harmony default export */ const hooks_useOutsideDetection = (useOutsideDetection);

;// CONCATENATED MODULE: ./components/ui/Modal.tsx




const Modal = ({ isShowing , children , title , onClose  })=>{
    const modalRef = (0,external_react_.useRef)(null);
    hooks_useOutsideDetection(modalRef, onClose);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: isShowing ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 mx-2 md:mx-0",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative max-w-lg md:max-w-xl lg:max-w-3xl mx-auto bg-background text-alternative shadow-lg border-2 border-primary/10 rounded-lg w-full",
                        ref: modalRef,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "absolute right-2 top-3",
                                onClick: onClose,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(outline_.XIcon, {
                                    className: "w-5 h-5 hover:text-alternative cursor-pointer"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "p-4 text-xl md:text-2xl font-semibold border-b border-primary/10 my-1 py-1",
                                children: title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "p-4 relative flex-auto",
                                children: children
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "opacity-25 fixed inset-0 z-40 bg-black "
                })
            ]
        }) : null
    });
};
/* harmony default export */ const ui_Modal = (Modal);

;// CONCATENATED MODULE: ./components/ui/TextInput.tsx


const TextInput = ({ handleChange , value , placeholder , inputType ="text" ,  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("input", {
        placeholder: placeholder,
        type: inputType,
        min: inputType === "number" ? 0 : "",
        className: "bg-primary text-main focus:outline-none p-2 w-full rounded-md placeholder:text-alternative",
        value: value,
        onChange: handleChange
    });
};
/* harmony default export */ const ui_TextInput = (TextInput);

;// CONCATENATED MODULE: ./components/feedback/Feedback.tsx






const defaultItem = "copyright";
const items = [
    {
        label: "DMCA / Copyright Infringement",
        query: defaultItem
    },
    {
        label: "Broken Video",
        query: "broken"
    },
    {
        label: "Inappropriate content",
        query: "age"
    },
    {
        label: "Support / Feedback",
        query: "others"
    }, 
];
const defaultFeedback = {
    email: "",
    message: "",
    subject: defaultItem,
    error: "",
    success: ""
};
const Feedback = ({ showModal , onClose  })=>{
    const { 0: feedback , 1: setFeedback  } = (0,external_react_.useState)(defaultFeedback);
    const updateDropdown = (newQuery)=>{
        updateFeedback({
            subject: newQuery
        });
    };
    const updateFeedback = (data)=>{
        setFeedback((currentFeedback)=>{
            return {
                ...currentFeedback,
                ...data
            };
        });
    };
    const submitFeedback = async ()=>{
        try {
            updateFeedback({
                success: "",
                error: ""
            });
            const response = await fetch("/api/feedback", {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(feedback)
            });
            const data = await response.json();
            if (data?.success) {
                updateFeedback({
                    email: "",
                    message: "",
                    subject: defaultItem,
                    success: "Thank you for your feedback!"
                });
            } else updateFeedback({
                error: data.message || "Something went wrong!"
            });
        } catch (err) {
            console.error(err);
        }
    };
    const { error , success , subject , message , email  } = feedback;
    return /*#__PURE__*/ jsx_runtime_.jsx(ui_Modal, {
        title: "Feedback",
        isShowing: showModal,
        onClose: onClose,
        children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col text-left space-y-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_Alert, {
                        message: error,
                        alertType: "danger"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_Alert, {
                        message: success,
                        alertType: "success"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-semibold",
                        children: "Subject"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Dropdown, {
                        items: items,
                        selectedQuery: subject,
                        updateFilterQuery: updateDropdown
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-semibold",
                        children: "E-Mail"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_TextInput, {
                        value: email,
                        placeholder: "Your E-Mail...",
                        handleChange: (e)=>{
                            updateFeedback({
                                email: e.target.value
                            });
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-semibold",
                        children: "Message"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        style: {
                            resize: "none"
                        },
                        className: "w-full bg-primary focus:outline-none rounded-md p-2 text-main placeholder:text-alternative",
                        rows: 5,
                        cols: 5,
                        value: message,
                        placeholder: `Enter message, please don't forget the video id.`,
                        onChange: (e)=>{
                            updateFeedback({
                                message: e.target.value
                            });
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: submitFeedback,
                        className: "bg-secondary w-full rounded-md p-2 text-main hover:brightness-125",
                        children: "Send"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const feedback_Feedback = (Feedback);


/***/ })

};
;