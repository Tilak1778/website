"use strict";
exports.id = 556;
exports.ids = [556];
exports.modules = {

/***/ 8547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(949);



const getTextSize = (variant)=>{
    const map = {
        h3: "text-xl md:text-2xl",
        h2: "text-2xl md:text-3xl",
        h1: "text-3xl md:text-4xl"
    };
    return map[variant] ?? "text-3xl md:text-4xl";
};
const Headline = ({ text , variant ="h1" , outline =false  })=>{
    let className = (0,utils_helpers__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)("mb-1 md:mb-3 font-semibold", getTextSize(variant), outline ? "text-main bg-primary rounded-md p-2 text-center md:text-left" : "text-main");
    if (variant == "h3") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
            className: className,
            children: text
        });
    }
    if (variant == "h2") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            className: className,
            children: text
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        className: className,
        children: text
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Headline);


/***/ }),

/***/ 1473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ connectToDb)
/* harmony export */ });
/* unused harmony export connectToDbHandler */
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);


const connectToDb = async ()=>{
    if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState)) {
        return;
    }
    await (0,mongoose__WEBPACK_IMPORTED_MODULE_0__.connect)(`mongodb://0.0.0.0:27017/tube_db`);
// await mongoose.connect(
//   `mongodb://localhost:27017/local/${process.env.DB_NAME}?retryWrites=true&w=majority`
// );
};
// /${process.env.DB_NAME}?retryWrites=true&w=majority
const connectToDbHandler = (handler)=>async (req, res)=>{
        await connectToDb();
        return handler(req, res);
    };


/***/ }),

/***/ 2097:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "i4": () => (/* binding */ getPopularTags),
  "A7": () => (/* binding */ getSEOTags)
});

// UNUSED EXPORTS: getRandomTags, searchRelatedTags

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./database/models/tags.model.ts

const tagsSchema = new (external_mongoose_default()).Schema({
    id: {
        type: String,
        require: [
            true,
            "lowecase(name) of tag is required."
        ],
        unique: true
    },
    name: {
        type: String,
        require: [
            true,
            "name of tag is required."
        ],
        trim: true
    },
    role: {
        type: String,
        enum: [
            "category",
            "tag",
            "model"
        ],
        default: "tag"
    },
    image: {
        type: String,
        default: ""
    },
    originalImage: {
        type: String,
        default: ""
    },
    isPriority: {
        type: Boolean,
        default: false
    },
    isParsed: {
        type: Boolean,
        default: false
    },
    videoCount: {
        type: Number,
        default: 0
    },
    relatedTags: {
        type: [
            String
        ],
        default: []
    }
}, {
    timestamps: true
});
tagsSchema.index({
    name: "text"
});
const tags_model_Tags = (external_mongoose_default()).models.Tags || external_mongoose_default().model("Tags", tagsSchema);
/* harmony default export */ const tags_model = (tags_model_Tags);

;// CONCATENATED MODULE: ./database/utils/helpers.ts
const generateTagId = (str)=>{
    return str.toLocaleLowerCase().trim();
};

;// CONCATENATED MODULE: ./database/services/tags.service.ts


const getRandomTags = async (amount, role = "tag", select = {})=>{
    try {
        const tags = Tags.aggregate([
            {
                $match: {
                    role: role
                }
            },
            {
                $project: select
            },
            {
                $sample: {
                    size: amount
                }
            }, 
        ]);
        if (!tags) throw new Error(`Could not find ${amount} Tags`);
        return tags;
    } catch (error) {
        throw error;
    }
};
const searchRelatedTags = async (name, limit, select = {})=>{
    try {
        const tags = await tags_model.find({
            id: {
                $ne: generateTagId(name)
            },
            $text: {
                $search: name,
                $caseSensitive: true,
                $diacriticSensitive: true
            },
            score: {
                $meta: "textScore"
            },
            role: "tag"
        }).sort({
            score: {
                $meta: "textScore"
            }
        }).limit(limit).select(select);
        return tags;
    } catch (err) {
        throw err;
    }
};
const getPopularTags = async (role, limit, select = {}, fillArray = true)=>{
    try {
        const tags = await tags_model.find({
            role: role,
            isPriority: true
        }).limit(limit).sort({
            videoCount: -1
        }).select(select);
        let moreTags = [];
        if (fillArray && tags.length < limit) {
            moreTags = await tags_model.find({
                role: role,
                isPriority: false
            }).limit(limit).sort({
                videoCount: -1
            }).select(select);
        }
        return tags.concat(moreTags);
    } catch (error) {
        throw error;
    }
};
const getSEOTags = async (keyword, limit, select = {})=>{
    const role = "tag";
    // 5 Prio Tags
    const prioTags = await tags_model.aggregate([
        {
            $match: {
                role: role,
                isPriority: true
            }
        },
        {
            $project: select
        },
        {
            $sample: {
                size: 5
            }
        }, 
    ]);
    // 5 Related Tags
    let relatedTags = [];
    if (keyword.length !== 0) {
        relatedTags = await searchRelatedTags(keyword, 5, select);
    }
    // fill with random till limit reached
    const randomTagsLimit = limit - relatedTags.length - prioTags.length;
    const randomTags = await tags_model.aggregate([
        {
            $match: {
                role: role,
                isPriority: false
            }
        },
        {
            $project: select
        },
        {
            $sample: {
                size: randomTagsLimit
            }
        }, 
    ]);
    let result = [];
    return result.concat(prioTags, relatedTags, randomTags);
};


/***/ }),

/***/ 9577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J9": () => (/* binding */ buildVideoUrl),
/* harmony export */   "Jm": () => (/* binding */ buildNavUrl),
/* harmony export */   "V1": () => (/* binding */ buildTagUrl)
/* harmony export */ });
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(949);

const buildTagUrl = (name, route = "tag", page = 1)=>{
    const url = "/" + `${(0,_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getRoute */ .Bv)(route)}/` + (0,_helpers__WEBPACK_IMPORTED_MODULE_0__/* .slugifyAndPage */ .VI)(name, page);
    return url;
};
const buildVideoUrl = (slug)=>{
    return "/" + `${(0,_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getRoute */ .Bv)("video")}/${slug}`;
};
const buildNavUrl = (route, page = 1)=>{
    let url = "/" + `${(0,_helpers__WEBPACK_IMPORTED_MODULE_0__/* .getRoute */ .Bv)(route)}`;
    if (page > 1) {
        url += `-${page}`;
    }
    return url;
};


/***/ })

};
;