"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/ui/Headline.tsx
var Headline = __webpack_require__(8547);
// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./utils/navigation.ts
var navigation = __webpack_require__(9577);
;// CONCATENATED MODULE: ./components/categories/CategoriesItem.tsx






const CategoriesItem = ({ name , image , count , role  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "text-main overflow-hidden group",
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: (0,navigation/* buildTagUrl */.V1)(name, role),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "rounded-xl",
                        alt: name,
                        src: image || "/images/thumb.png",
                        layout: "responsive",
                        width: 400,
                        height: 250
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row justify-between items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "inline-flex mx-2 mt-2 text-sm md:text-base font-semibold mb-2 items-center",
                                children: name
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "inline-flex mx-2 mt-2 text-xs md:text-sm font-semibold mb-2 items-center",
                                children: [
                                    count,
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(outline_.VideoCameraIcon, {
                                        className: "ml-1 w-5 h-5"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const categories_CategoriesItem = (CategoriesItem);

;// CONCATENATED MODULE: ./components/categories/CategoriesSection.tsx




const CategoriesSection = ({ headline , categories , variant ="h1" ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Headline/* default */.Z, {
                variant: variant,
                text: headline
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid grid-cols-2 lg:grid-cols-3 xl:gird-cols-4 gap-5 my-6",
                children: categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(categories_CategoriesItem, {
                        role: category.role,
                        name: category.name,
                        image: category.image,
                        count: category.videoCount
                    }, category.id))
            })
        ]
    });
};
/* harmony default export */ const categories_CategoriesSection = (CategoriesSection);

// EXTERNAL MODULE: ./components/tags/TagSection.tsx + 1 modules
var TagSection = __webpack_require__(6041);
// EXTERNAL MODULE: ./components/videos/VideosSection.tsx + 3 modules
var VideosSection = __webpack_require__(4320);
// EXTERNAL MODULE: ./database/services/tags.service.ts + 2 modules
var tags_service = __webpack_require__(2097);
// EXTERNAL MODULE: ./database/database.ts
var database = __webpack_require__(1473);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(949);
// EXTERNAL MODULE: ./database/services/videos.service.ts + 2 modules
var videos_service = __webpack_require__(1249);
// EXTERNAL MODULE: ./database/selectors/index.ts
var selectors = __webpack_require__(7235);
// EXTERNAL MODULE: ./tube.config.js
var tube_config = __webpack_require__(8486);
;// CONCATENATED MODULE: ./pages/index.tsx










const HomePage = ({ categories , videos , tags  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(categories_CategoriesSection, {
                headline: "Categories",
                variant: "h2",
                categories: categories
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(VideosSection/* default */.Z, {
                headline: "Latest Videos",
                variant: "h2",
                videos: videos
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TagSection/* default */.Z, {
                headline: "Popular Searches",
                variant: "h2",
                tags: tags
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    await (0,database/* connectToDb */.T)();
    const videos = await (0,videos_service/* getRandomVideos */.lY)(tube_config.index.videosLimit, selectors/* videoPreviewSelector */.QA);
    const tags = await (0,tags_service/* getSEOTags */.A7)("", tube_config.index.tagsLimit, {
        _id: 0,
        name: 1
    });
    const categories = await (0,tags_service/* getPopularTags */.i4)(tube_config.index.categoriesSectionRole, tube_config.index.categoriesSectionLimit, selectors/* categorySelector */.uT);
    return {
        props: {
            categories: (0,helpers/* toJson */.Qs)(categories),
            videos: (0,helpers/* toJson */.Qs)(videos),
            tags: (0,helpers/* toJson */.Qs)(tags.map((tag)=>tag.name))
        }
    };
};
/* harmony default export */ const pages = (HomePage);


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 9542:
/***/ ((module) => {

module.exports = require("millify");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,675,949,556,511], () => (__webpack_exec__(9250)));
module.exports = __webpack_exports__;

})();