"use strict";
(() => {
var exports = {};
exports.id = 562;
exports.ids = [562];
exports.modules = {

/***/ 225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7282);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Pagination = ({ currentPage , hrefPrevPage , hrefNextPage , maxPage =5 ,  })=>{
    const nextPage = currentPage + 1;
    const prevPage = currentPage - 1;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-row space-x-1 md:space-x-2 justify-center w-full my-5",
        children: [
            prevPage > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                text: "< Prev",
                href: hrefPrevPage,
                outline: true
            }),
            nextPage <= maxPage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                text: "Next >",
                href: hrefNextPage,
                outline: true
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pagination);


/***/ }),

/***/ 9820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _db_database__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1473);
/* harmony import */ var _db_services_tags_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2097);
/* harmony import */ var _db_services_videos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1249);
/* harmony import */ var components_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(225);
/* harmony import */ var components_tags_TagSection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6041);
/* harmony import */ var components_videos_VideosSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4320);
/* harmony import */ var _db_selectors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7235);
/* harmony import */ var utils_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(949);
/* harmony import */ var tube_config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8486);
/* harmony import */ var tube_config__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(tube_config__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var utils_navigation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9577);











const TagPage = ({ videos , page , keyword , tags , role  })=>{
    const configData = (tube_config__WEBPACK_IMPORTED_MODULE_9___default())[role];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_videos_VideosSection__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                headline: `${keyword}`,
                videos: videos
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_pagination__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                hrefPrevPage: (0,utils_navigation__WEBPACK_IMPORTED_MODULE_10__/* .buildTagUrl */ .V1)(keyword, role, page - 1),
                hrefNextPage: (0,utils_navigation__WEBPACK_IMPORTED_MODULE_10__/* .buildTagUrl */ .V1)(keyword, role, page + 1),
                currentPage: page,
                maxPage: configData.maxPage
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_tags_TagSection__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                headline: "Related Tags",
                variant: "h2",
                tags: tags
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    const path = context.query.path;
    const pageData = (0,utils_helpers__WEBPACK_IMPORTED_MODULE_8__/* .getPage */ .fx)(context.query.keyword);
    if (!pageData || !(0,utils_helpers__WEBPACK_IMPORTED_MODULE_8__/* .validateTagRole */ .h)(path)) {
        return {
            redirect: {
                destination: "/",
                permanent: true
            }
        };
    }
    const configData = (tube_config__WEBPACK_IMPORTED_MODULE_9___default())[path];
    if (pageData.page > configData.maxPage) return {
        redirect: {
            destination: "/",
            permanent: true
        }
    };
    await (0,_db_database__WEBPACK_IMPORTED_MODULE_1__/* .connectToDb */ .T)();
    const { page , keyword  } = pageData;
    const videos = await (0,_db_services_videos_service__WEBPACK_IMPORTED_MODULE_3__/* .searchVideos */ .oo)(keyword, configData.videosLimit, _db_selectors__WEBPACK_IMPORTED_MODULE_7__/* .videoPreviewSelector */ .QA);
    const tags = await (0,_db_services_tags_service__WEBPACK_IMPORTED_MODULE_2__/* .getSEOTags */ .A7)(keyword, configData.tagsLimit, {
        _id: 0,
        name: 1
    });
    return {
        props: {
            page,
            keyword,
            videos: (0,utils_helpers__WEBPACK_IMPORTED_MODULE_8__/* .toJson */ .Qs)(videos),
            tags: (0,utils_helpers__WEBPACK_IMPORTED_MODULE_8__/* .toJson */ .Qs)(tags.map((tag)=>tag.name)),
            role: (0,utils_helpers__WEBPACK_IMPORTED_MODULE_8__/* .getTagRoleByRoute */ .tP)(path)
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TagPage);


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 9542:
/***/ ((module) => {

module.exports = require("millify");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,675,949,556,511,282], () => (__webpack_exec__(9820)));
module.exports = __webpack_exports__;

})();