"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 1268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./components/footer/index.tsx



const Modal = dynamic_default()(()=>__webpack_require__.e(/* import() */ 58).then(__webpack_require__.bind(__webpack_require__, 2058)), {
    loadableGenerated: {
        modules: [
            "..\\components\\footer\\index.tsx -> " + "components/feedback/Feedback"
        ]
    }
});
const Footer = (props)=>{
    const { 0: showModal , 1: setShowModal  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "py-4 text-center border-t border-primary/10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-2 text-sm max-w-5xl mx-auto text-alternative brightness-90",
                children: [
                    "Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident voluptates magni eveniet velit cum vero nobis soluta ipsa",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "text-color brightness-125 hover:brightness-150",
                        onClick: ()=>{
                            setShowModal(!showModal);
                        },
                        children: "feedback"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-alternative text-sm font-semibold",
                children: "NextTube Copyright 2022"
            }),
            showModal && /*#__PURE__*/ jsx_runtime_.jsx(Modal, {
                showModal: showModal,
                onClose: ()=>{
                    setShowModal(false);
                }
            })
        ]
    });
};
/* harmony default export */ const footer = (Footer);

// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
;// CONCATENATED MODULE: ./components/navbar/NavButton.tsx


const NavButton = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        onClick: props.onClick,
        className: "py-2 px-2 border-2 border-transparent text-base md:text-md font-medium rounded-md text-white bg-secondary hover:brightness-125 hover:border-secondary",
        children: props.children
    });
};
/* harmony default export */ const navbar_NavButton = (NavButton);

;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(949);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/navbar/NavItem.tsx




const NavItem = ({ title , href , brand =false , active =false  })=>{
    let className = (0,helpers/* classNames */.AK)("px-2 py-2 text-main hover:text-main", brand ? "font-bold text-xl hover:text-main" : "text-main hover:bg-secondary hover:rounded-md", active ? "md:border-b-2 md:border-b-secondary font-semibold" : "");
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: href,
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: className,
                children: title
            })
        })
    });
};
/* harmony default export */ const navbar_NavItem = (NavItem);

;// CONCATENATED MODULE: ./components/navbar/Search.tsx





const Search = ({ showMobileSearch  })=>{
    const { 0: query , 1: setQuery  } = (0,external_react_.useState)("");
    const showClearSearch = query.length > 0;
    const router = (0,router_namespaceObject.useRouter)();
    const handleSearch = (e)=>{
        e.preventDefault();
        // at least 3 chars for a search
        if (query.length < 3) return;
        const slugifiedQuery = (0,helpers/* slugifyAndPage */.VI)(query);
        setQuery("");
        router.push(`/tag/${slugifiedQuery}`);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${showMobileSearch ? "fixed top-16 right-2 left-2" : "hidden"} md:relative md:top-0 md:left-0 md:flex bg-secondary rounded-md mx-auto`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `${showMobileSearch ? "bg-background pb-2" : "bg-background"} flex flex-row rounded-md`,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            className: "p-2 rounded-l-md w-full md:w-64 bg-primary text-main focus:outline-none placeholder:text-alternative",
                            type: "text",
                            value: query,
                            onChange: (e)=>{
                                setQuery(e.target.value);
                            },
                            placeholder: "What are you searching..."
                        }),
                        showClearSearch && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute right-2 top-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(outline_.XIcon, {
                                className: "h-4 w-4 text-main hover:text-main/80 cursor-pointer",
                                onClick: ()=>{
                                    setQuery("");
                                }
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    onClick: handleSearch,
                    className: "px-3 py-2 bg-secondary hover:brightness-125 rounded-r-md",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(outline_.SearchIcon, {
                        className: "h-5 w-5 text-white"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const navbar_Search = (Search);

;// CONCATENATED MODULE: ./components/navbar/index.tsx








const navigation = [
    {
        name: "New",
        href: "/new"
    },
    {
        name: "Top",
        href: "/top"
    },
    {
        name: "Models",
        href: "/models"
    }, 
];
const Navbar = ({})=>{
    const { 0: showMobileNav , 1: setShowMobileNav  } = (0,external_react_.useState)(false);
    const { 0: showMobileSearch , 1: setShowMobileSearch  } = (0,external_react_.useState)(false);
    const { 0: visible , 1: setVisible  } = (0,external_react_.useState)(true);
    const { asPath  } = (0,router_namespaceObject.useRouter)();
    const handleScroll = ()=>{
        const currentScrollPos = window.scrollY;
        // disabled for now...
        return;
        if (currentScrollPos > 250) {
            setVisible(false);
            setShowMobileSearch(false);
            setShowMobileNav(false);
        } else {
            setVisible(true);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    const fullClass = showMobileNav ? "w-full" : "";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: `sticky z-10 border-b bg-background border-primary/10 backdrop-blur bg-opacity-80 ${visible ? "top-0" : ""}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: "flex flex-row justify-between items-center max-w-5xl mx-auto px-2 lg:px-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "md:hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(navbar_NavButton, {
                            onClick: ()=>{
                                if (!showMobileNav) {
                                    setShowMobileSearch(false);
                                }
                                setShowMobileNav(!showMobileNav);
                            },
                            children: showMobileNav ? /*#__PURE__*/ jsx_runtime_.jsx(outline_.XIcon, {
                                className: "w-5 h-5"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(outline_.MenuIcon, {
                                className: "w-5 h-5"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "md:hidden",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(navbar_NavItem, {
                            brand: true,
                            href: "/",
                            title: "NextTube"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `${showMobileNav ? "" : "hidden"} fixed md:relative md:flex md:flex-row md:items-center md:justify-start md:top-0 top-14 w-full pb-2 py-2 border-none`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "flex flex-col md:flex-row mr-4 md:mr-0 md:space-x-2 items-center justify-items-center bg-primary md:bg-transparent text-center rounded-md border border-transparent",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "hidden md:flex",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(navbar_NavItem, {
                                        brand: true,
                                        href: "/",
                                        title: "NextTube"
                                    })
                                }),
                                navigation.map((navItem, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: fullClass,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(navbar_NavItem, {
                                            href: navItem.href,
                                            title: navItem.name,
                                            active: (0,helpers/* removePageFromPath */.vf)(asPath) === navItem.href
                                        })
                                    }, i))
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center justify-center space-x-2 py-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(navbar_Search, {
                                showMobileSearch: showMobileSearch
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex md:hidden items-center py-2",
                                onClick: ()=>{
                                    if (!showMobileSearch) {
                                        setShowMobileNav(false);
                                    }
                                    setShowMobileSearch(!showMobileSearch);
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(navbar_NavButton, {
                                    children: showMobileSearch ? /*#__PURE__*/ jsx_runtime_.jsx(outline_.XIcon, {
                                        className: "w-5 h-5"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(outline_.SearchIcon, {
                                        className: "h-5 w-5"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            showMobileSearch && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mb-12"
            }),
            showMobileNav && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mb-36"
            })
        ]
    });
};
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./components/layout/BaseLayout.tsx




const BaseLayout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-background text-main",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "container max-w-5xl mx-auto min-h-screen px-2 lg:px-0",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    });
};
/* harmony default export */ const layout_BaseLayout = (BaseLayout);

;// CONCATENATED MODULE: ./pages/_app.tsx



function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(layout_BaseLayout, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,152,949], () => (__webpack_exec__(1268)));
module.exports = __webpack_exports__;

})();