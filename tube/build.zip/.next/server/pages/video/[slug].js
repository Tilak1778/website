"use strict";
(() => {
var exports = {};
exports.id = 274;
exports.ids = [274];
exports.modules = {

/***/ 8741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./database/database.ts
var database = __webpack_require__(1473);
// EXTERNAL MODULE: ./database/services/videos.service.ts + 2 modules
var videos_service = __webpack_require__(1249);
// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(949);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
// EXTERNAL MODULE: external "millify"
var external_millify_ = __webpack_require__(9542);
var external_millify_default = /*#__PURE__*/__webpack_require__.n(external_millify_);
;// CONCATENATED MODULE: external "react-timeago"
const external_react_timeago_namespaceObject = require("react-timeago");
var external_react_timeago_default = /*#__PURE__*/__webpack_require__.n(external_react_timeago_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./utils/navigation.ts
var navigation = __webpack_require__(9577);
;// CONCATENATED MODULE: ./components/video/VideoCategories.tsx





const VideoCategories = ({ categories , models  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row mt-2 items-center justify-start flex-wrap overflow-hidden mb-2 md:mb-0",
        children: [
            categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: (0,navigation/* buildTagUrl */.V1)(category, "category"),
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "py-1 px-3 border-2 border-secondary hover:bg-secondary rounded-md cursor-pointer mr-2 mb-2 inline-flex items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(outline_.UserCircleIcon, {
                                    className: "w-5 h-5 mr-1"
                                }),
                                " ",
                                category
                            ]
                        })
                    })
                }, category)),
            models.map((model)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: (0,navigation/* buildTagUrl */.V1)(model, "model"),
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "py-1 px-3 border-2 border-secondary hover:bg-secondary rounded-md cursor-pointer mr-2 mb-2 inline-flex items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(outline_.UserCircleIcon, {
                                    className: "w-5 h-5 mr-1"
                                }),
                                " ",
                                model
                            ]
                        })
                    })
                }, model))
        ]
    });
};
/* harmony default export */ const video_VideoCategories = (VideoCategories);

;// CONCATENATED MODULE: ./components/video/VideoTags.tsx




const VideoTags = ({ tags  })=>{
    if (tags.length === 0) {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row flex-wrap items-baseline justify-start",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-main mr-2",
                children: "Tags:"
            }),
            tags.map((tag, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex mb-1 mr-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: (0,navigation/* buildTagUrl */.V1)(tag, "tag"),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-color hover:brightness-125 cursor-pointer",
                                    children: `# ${tag}`
                                })
                            })
                        }),
                        i < tags.length - 1 && ","
                    ]
                }, tag))
        ]
    });
};
/* harmony default export */ const video_VideoTags = (VideoTags);

// EXTERNAL MODULE: ./components/ui/Button.tsx
var Button = __webpack_require__(7282);
;// CONCATENATED MODULE: ./components/video/VideoComments.tsx



const VideoComments = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full py-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "border border-primary/30 w-full"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col space-y-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-lg font-semibold",
                        children: "Comments"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        className: "w-full p-2 rounded-md cursor-not-allowed placeholder:text-alternative bg-primary brightness-125",
                        disabled: true,
                        placeholder: "Please login to post comment"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row justify-center md:justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-alternative w-60",
                                children: "250 Charaters left"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                text: "Submit Comment"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const video_VideoComments = (VideoComments);

;// CONCATENATED MODULE: ./components/video/index.tsx









const Modal = dynamic_default()(()=>__webpack_require__.e(/* import() */ 58).then(__webpack_require__.bind(__webpack_require__, 2058)), {
    loadableGenerated: {
        modules: [
            "..\\components\\video\\index.tsx -> " + "components/feedback/Feedback"
        ]
    }
});
const VideoSection = ({ video  })=>{
    const { 0: showModal , 1: setShowModal  } = (0,external_react_.useState)(false);
    const hasCategories = video.categories.length > 0 || video.models.length > 0;
    console.log("src = " + video.src);
    //embed_url = "https://www.pornhub.com/embed/"+video.src.split('=')[1]
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mt-1",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full flex flex-col py-2 text-main space-y-3",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                            src: "https://www.pornhub.com/embed/" + video.src.split("=")[1],
                            frameBorder: "0",
                            width: "560",
                            height: "340",
                            scrolling: "no",
                            allowFullScreen: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "font-semibold text-xl md:text-4xl",
                            children: video.title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col md:flex-row items-left md:items-center justify-between md:space-x-3 md:space-y-0 text-sm md:text-base",
                            children: [
                                hasCategories && /*#__PURE__*/ jsx_runtime_.jsx(video_VideoCategories, {
                                    categories: video.categories,
                                    models: video.models
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row justify-start space-x-2 md:space-x-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row justify-center",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    className: "rounded-l-full bg-primary hover:text-color inline-flex py-2 pr-2 pl-3 font-semibold items-center ",
                                                    children: [
                                                        video.likes,
                                                        /*#__PURE__*/ jsx_runtime_.jsx(outline_.ThumbUpIcon, {
                                                            className: "ml-1 w-5 h-5"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "bg-primary flex",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "border-r border-r-primary/40 my-2 "
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    className: "rounded-r-full bg-primary hover:text-color inline-flex py-2 pr-3 pl-2 font-semibold items-center ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(outline_.ThumbDownIcon, {
                                                            className: "w-5 h-5 mr-1"
                                                        }),
                                                        video.dislikes
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                            onClick: ()=>{
                                                setShowModal(true);
                                            },
                                            className: "rounded-full bg-primary py-2 px-3 flex hover:text-color font-semibold items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(outline_.FlagIcon, {
                                                    className: "w-5 h-5 mr-1"
                                                }),
                                                "Report"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col space-y-1 bg-primary/90 py-2 px-3 rounded-md text-sm md:text-base",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row space-x-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "font-semibold",
                                            children: [
                                                external_millify_default()(video.views),
                                                " views"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "font-semibold",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_timeago_default()), {
                                                live: false,
                                                date: video.createdAt
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex",
                                    children: "test"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(video_VideoTags, {
                                    tags: video.tags
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(video_VideoComments, {})
                            ]
                        })
                    ]
                })
            }),
            showModal && /*#__PURE__*/ jsx_runtime_.jsx(Modal, {
                showModal: showModal,
                onClose: ()=>{
                    setShowModal(false);
                }
            })
        ]
    });
};
/* harmony default export */ const components_video = (VideoSection);

// EXTERNAL MODULE: ./components/videos/VideosSection.tsx + 3 modules
var VideosSection = __webpack_require__(4320);
// EXTERNAL MODULE: ./database/selectors/index.ts
var selectors = __webpack_require__(7235);
// EXTERNAL MODULE: ./tube.config.js
var tube_config = __webpack_require__(8486);
// EXTERNAL MODULE: ./database/services/tags.service.ts + 2 modules
var tags_service = __webpack_require__(2097);
// EXTERNAL MODULE: ./components/tags/TagSection.tsx + 1 modules
var TagSection = __webpack_require__(6041);
;// CONCATENATED MODULE: ./pages/video/[slug].tsx










const VideoPage = ({ video , relevantVideos , tags  })=>{
    console.log(video.id);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_video, {
                video: video
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(VideosSection/* default */.Z, {
                headline: "Most Related Videos",
                variant: "h2",
                videos: relevantVideos
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TagSection/* default */.Z, {
                headline: "Popular Searches",
                variant: "h2",
                tags: tags
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    const { slug  } = context.query;
    console.log(slug);
    if (!slug) {
        return {
            redirect: {
                destination: "/",
                permanent: true
            }
        };
    }
    await (0,database/* connectToDb */.T)();
    const video = await (0,videos_service/* getVideoById */.mJ)(Number(slug), true, selectors/* videoFullSelector */.Jf);
    //console.log(video)
    if (!video) {
        return {
            redirect: {
                destination: "/",
                permanent: true
            }
        };
    }
    const searchString = `${video.title} ${video.alternativeTitle} ${video.tags.join(" ")} ${video.categories.join(" ")} ${video.models.join(" ")}`;
    const relatedVideos = await (0,videos_service/* searchRelatedVideos */.Uw)(video.id, searchString, tube_config.video.videosLimit, selectors/* videoPreviewSelector */.QA);
    const tags = await (0,tags_service/* getSEOTags */.A7)(`${video.title} ${video.alternativeTitle}`, tube_config.video.tagsLimit, {
        _id: 0,
        name: 1
    });
    return {
        props: {
            video: (0,helpers/* toJson */.Qs)(video),
            relevantVideos: (0,helpers/* toJson */.Qs)(relatedVideos),
            tags: (0,helpers/* toJson */.Qs)(tags.map((tag)=>tag.name))
        }
    };
};
/* harmony default export */ const _slug_ = (VideoPage);


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 9542:
/***/ ((module) => {

module.exports = require("millify");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,675,152,949,556,511,282], () => (__webpack_exec__(8741)));
module.exports = __webpack_exports__;

})();