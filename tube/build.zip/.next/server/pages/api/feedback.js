"use strict";
(() => {
var exports = {};
exports.id = 240;
exports.ids = [240];
exports.modules = {

/***/ 3621:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ feedback)
});

;// CONCATENATED MODULE: external "mongoose"
const external_mongoose_namespaceObject = require("mongoose");
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_namespaceObject);
;// CONCATENATED MODULE: ./database/database.ts


const connectToDb = async ()=>{
    if ((external_mongoose_default()).connections[0].readyState) {
        return;
    }
    await (0,external_mongoose_namespaceObject.connect)(`mongodb://0.0.0.0:27017/tube_db`);
// await mongoose.connect(
//   `mongodb://localhost:27017/local/${process.env.DB_NAME}?retryWrites=true&w=majority`
// );
};
// /${process.env.DB_NAME}?retryWrites=true&w=majority
const connectToDbHandler = (handler)=>async (req, res)=>{
        await connectToDb();
        return handler(req, res);
    };

;// CONCATENATED MODULE: ./database/models/counter.model.ts

const counterSchema = new (external_mongoose_default()).Schema({
    _id: {
        type: String,
        required: true
    },
    seq: {
        type: Number,
        default: 0
    }
});
const Counter = (external_mongoose_default()).models.Counter || external_mongoose_default().model("Counter", counterSchema);
/* harmony default export */ const counter_model = (Counter);

;// CONCATENATED MODULE: ./database/models/feedbacks.model.ts


const feedbacksSchema = new (external_mongoose_default()).Schema({
    id: {
        type: Number,
        required: [
            true,
            "feedback id is required"
        ],
        unique: true,
        min: 1
    },
    message: {
        type: String,
        require: [
            true,
            "message of feedback is required."
        ]
    },
    email: {
        type: String,
        require: [
            true,
            "email of feedback is required."
        ]
    },
    subject: {
        type: String,
        enum: [
            "copyright",
            "age",
            "broken",
            "other"
        ],
        default: "copyright",
        require: true
    },
    hasSeen: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});
feedbacksSchema.pre("save", function(next) {
    var doc = this;
    counter_model.findByIdAndUpdate({
        _id: "feedbacks"
    }, {
        $inc: {
            seq: 1
        }
    }, {
        new: true,
        upsert: true
    }, function(error, counter) {
        if (error) return next(error);
        doc.id = counter.seq;
        next();
    });
});
const Feedbacks = (external_mongoose_default()).models.Feedbacks || external_mongoose_default().model("Feedbacks", feedbacksSchema);
/* harmony default export */ const feedbacks_model = (Feedbacks);

;// CONCATENATED MODULE: ./database/services/feedbacks.service.ts

const addFeedback = async (req)=>{
    try {
        const { message , email , subject  } = req.body;
        if (!message || message.length < 1) {
            throw "Message can't be empty!";
        }
        if (!email || email.length < 1 || !email.includes("@")) {
            throw "E-Mail is not valid!";
        }
        if (!subject) {
            throw "A subject is needed!";
        }
        const feedback = new feedbacks_model({
            id: 1,
            subject,
            email,
            message
        });
        await feedback.save();
        return feedback;
    } catch (err) {
        throw err;
    }
};

;// CONCATENATED MODULE: ./pages/api/feedback/index.ts


const handler = async (req, res)=>{
    try {
        if (req.method === "POST") {
            await addFeedback(req);
            return res.status(200).send({
                success: true
            });
        }
    } catch (err) {
        return res.status(400).json({
            success: false,
            message: `${err || "Unknown error"}`
        });
    }
    return res.status(400).json({
        message: "API Error"
    });
};
/* harmony default export */ const feedback = (connectToDbHandler(handler));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3621));
module.exports = __webpack_exports__;

})();