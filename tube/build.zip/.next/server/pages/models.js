"use strict";
(() => {
var exports = {};
exports.id = 729;
exports.ids = [729];
exports.modules = {

/***/ 4201:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ models),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./database/database.ts
var database = __webpack_require__(1473);
// EXTERNAL MODULE: ./database/services/tags.service.ts + 2 modules
var tags_service = __webpack_require__(2097);
// EXTERNAL MODULE: ./components/ui/Headline.tsx
var Headline = __webpack_require__(8547);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./utils/navigation.ts
var navigation = __webpack_require__(9577);
;// CONCATENATED MODULE: ./components/list/ListItem.tsx




const ListItem = ({ item , role  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: "w-full",
        children: item.length === 1 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-color bg-secondary/10 px-1 font-bold rounded-md",
            children: item
        }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: (0,navigation/* buildTagUrl */.V1)(item, role),
            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "px-1 hover:bg-secondary hover:rounded-md",
                    children: item
                })
            })
        })
    }, item);
};
/* harmony default export */ const list_ListItem = (ListItem);

;// CONCATENATED MODULE: ./components/list/ListSection.tsx




const prepareList = (keywords)=>{
    const sortedList = [];
    const keywordsSorted = keywords.slice().sort();
    for (let item of keywordsSorted){
        const firstLetter = item.toLowerCase().charAt(0).toUpperCase();
        if (firstLetter.match(/[a-z]/i)) {
            if (!sortedList.includes(firstLetter)) {
                sortedList.push(firstLetter);
            }
            if (!sortedList.includes(item)) {
                sortedList.push(item);
            }
        }
    }
    return sortedList;
};
const ListSection = ({ keywords , headline , variant ="h2" , role ="tag" ,  })=>{
    const sortedList = (0,external_react_.useMemo)(()=>prepareList(keywords), [
        keywords
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Headline/* default */.Z, {
                variant: variant,
                text: headline
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-background text-main rounded-md py-2 px-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "columns-1 md:columns-2 lg:columns-3 xl:columns-4 items-center text-sm md:text-base",
                    children: sortedList.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx(list_ListItem, {
                            item: item,
                            role: role
                        }, item))
                })
            })
        ]
    });
};
/* harmony default export */ const list_ListSection = (ListSection);

// EXTERNAL MODULE: ./utils/helpers.ts
var helpers = __webpack_require__(949);
// EXTERNAL MODULE: ./tube.config.js
var tube_config = __webpack_require__(8486);
;// CONCATENATED MODULE: ./pages/models.tsx






const HomePage = ({ models  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(list_ListSection, {
            keywords: models,
            headline: "Models",
            role: "model"
        })
    });
};
const getServerSideProps = async (context)=>{
    await (0,database/* connectToDb */.T)();
    const models = await (0,tags_service/* getPopularTags */.i4)(tube_config.toplist.role, tube_config.toplist.listLimit, {
        _id: 0,
        name: 1
    });
    return {
        props: {
            models: (0,helpers/* toJson */.Qs)(models.map((model)=>model.name))
        }
    };
};
/* harmony default export */ const models = (HomePage);


/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,949,556], () => (__webpack_exec__(4201)));
module.exports = __webpack_exports__;

})();